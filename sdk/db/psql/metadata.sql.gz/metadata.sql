--
-- PostgreSQL database dump
--

-- Dumped from database version 13.7 (Debian 13.7-1.pgdg110+1)
-- Dumped by pg_dump version 13.7 (Debian 13.7-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: metadata_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO metadata_user;

--
-- Name: metadata; Type: TABLE; Schema: public; Owner: metadata_user
--

CREATE TABLE public.metadata (
    guid character varying NOT NULL,
    data jsonb,
    authz jsonb NOT NULL
);


ALTER TABLE public.metadata OWNER TO metadata_user;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: metadata_user
--

INSERT INTO public.alembic_version VALUES ('4d93784a25e5');


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: public; Owner: metadata_user
--



--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: metadata_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: metadata metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: metadata_user
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT metadata_pkey PRIMARY KEY (guid);


--
-- PostgreSQL database dump complete
--

