--
-- PostgreSQL database dump
--

-- Dumped from database version 13.7 (Debian 13.7-1.pgdg110+1)
-- Dumped by pg_dump version 13.7 (Debian 13.7-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ltree; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS ltree WITH SCHEMA public;


--
-- Name: EXTENSION ltree; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION ltree IS 'data type for hierarchical tree-like structures';


--
-- Name: grp_protect_built_in(); Type: FUNCTION; Schema: public; Owner: arborist_user
--

CREATE FUNCTION public.grp_protect_built_in() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF OLD.name = 'anonymous' OR OLD.name = 'logged-in' THEN
        RAISE EXCEPTION 'Cannot delete built-in groups';
    END IF;
    RETURN OLD;
END;
$$;


ALTER FUNCTION public.grp_protect_built_in() OWNER TO arborist_user;

--
-- Name: random_bytea(integer); Type: FUNCTION; Schema: public; Owner: arborist_user
--

CREATE FUNCTION public.random_bytea(bytea_length integer) RETURNS bytea
    LANGUAGE sql
    AS $_$
    SELECT decode(string_agg(lpad(to_hex(width_bucket(random(), 0, 1, 256)-1),2,'0') ,''), 'hex')
    FROM generate_series(1, $1);
$_$;


ALTER FUNCTION public.random_bytea(bytea_length integer) OWNER TO arborist_user;

--
-- Name: resource_has_parent(); Type: FUNCTION; Schema: public; Owner: arborist_user
--

CREATE FUNCTION public.resource_has_parent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE parent integer;
BEGIN
    -- If there's only one path segment, we're at the root, so it's fine if there's no parent.
    IF (nlevel(NEW.path) = 1) THEN
        RETURN NEW;
    END IF;
    parent := (SELECT COUNT(*) FROM resource WHERE path = subpath(NEW.path, 0, -1));
    IF (parent = 0) THEN
        RAISE EXCEPTION 'Parent resource % does not exist; cannot create resource with path %', subpath(NEW.path, 0, -1), NEW.path;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.resource_has_parent() OWNER TO arborist_user;

--
-- Name: resource_path_insert(); Type: FUNCTION; Schema: public; Owner: arborist_user
--

CREATE FUNCTION public.resource_path_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE found integer;
BEGIN
    NEW.name = (ltree2text(subpath(NEW.path, -1)));

    -- also generate a unique "tag" for the resource
    IF NOT EXISTS(SELECT 1 FROM resource WHERE id = NEW.id) THEN
        LOOP
            NEW.tag = encode(random_bytea(6), 'base64');
            -- make it URL safe
            NEW.tag = replace(NEW.tag, '/', '_');
            NEW.tag = replace(NEW.tag, '+', '-');
            -- try to guarantee uniqueness
            -- (no guarantees for concurrent transactions)
            EXECUTE 'SELECT COUNT(*) FROM resource WHERE tag = ' || quote_literal(NEW.tag) INTO found;
            IF (found = 0) THEN
                -- not a duplicate; exit loop
                EXIT;
            END IF;
        END LOOP;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.resource_path_insert() OWNER TO arborist_user;

--
-- Name: resource_path_update(); Type: FUNCTION; Schema: public; Owner: arborist_user
--

CREATE FUNCTION public.resource_path_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE found integer;
BEGIN
    NEW.name = (ltree2text(subpath(NEW.path, -1)));
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.resource_path_update() OWNER TO arborist_user;

--
-- Name: resource_recursive_delete(); Type: FUNCTION; Schema: public; Owner: arborist_user
--

CREATE FUNCTION public.resource_recursive_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- `x <@ y` is satisfied when x is a descendant of y. Also omit the resource
    -- itself from this delete to prevent recursively activating this trigger
    -- with the same delete.
    DELETE FROM resource WHERE (path != OLD.path) AND (path <@ OLD.path);
    RETURN OLD;
END;
$$;


ALTER FUNCTION public.resource_recursive_delete() OWNER TO arborist_user;

--
-- Name: resource_recursive_update(); Type: FUNCTION; Schema: public; Owner: arborist_user
--

CREATE FUNCTION public.resource_recursive_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE resource SET path = subpath(path, 0, nlevel(OLD.path)-1) || subpath(NEW.PATH, -1) || subpath(path, nlevel(OLD.path)) WHERE (path <@ OLD.path AND path != OLD.path);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.resource_recursive_update() OWNER TO arborist_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: client; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.client (
    id integer NOT NULL,
    external_client_id text NOT NULL
);


ALTER TABLE public.client OWNER TO arborist_user;

--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: arborist_user
--

CREATE SEQUENCE public.client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_id_seq OWNER TO arborist_user;

--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arborist_user
--

ALTER SEQUENCE public.client_id_seq OWNED BY public.client.id;


--
-- Name: client_policy; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.client_policy (
    client_id integer NOT NULL,
    policy_id integer NOT NULL,
    authz_provider character varying
);


ALTER TABLE public.client_policy OWNER TO arborist_user;

--
-- Name: db_version; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.db_version (
    id integer NOT NULL,
    version text NOT NULL
);


ALTER TABLE public.db_version OWNER TO arborist_user;

--
-- Name: grp; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.grp (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.grp OWNER TO arborist_user;

--
-- Name: grp_id_seq; Type: SEQUENCE; Schema: public; Owner: arborist_user
--

CREATE SEQUENCE public.grp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grp_id_seq OWNER TO arborist_user;

--
-- Name: grp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arborist_user
--

ALTER SEQUENCE public.grp_id_seq OWNED BY public.grp.id;


--
-- Name: grp_policy; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.grp_policy (
    grp_id integer NOT NULL,
    policy_id integer NOT NULL,
    authz_provider character varying
);


ALTER TABLE public.grp_policy OWNER TO arborist_user;

--
-- Name: permission; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.permission (
    role_id integer NOT NULL,
    name text NOT NULL,
    service text NOT NULL,
    method text NOT NULL,
    constraints jsonb DEFAULT '{}'::jsonb,
    description text
);


ALTER TABLE public.permission OWNER TO arborist_user;

--
-- Name: policy; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.policy (
    id integer NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.policy OWNER TO arborist_user;

--
-- Name: policy_id_seq; Type: SEQUENCE; Schema: public; Owner: arborist_user
--

CREATE SEQUENCE public.policy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.policy_id_seq OWNER TO arborist_user;

--
-- Name: policy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arborist_user
--

ALTER SEQUENCE public.policy_id_seq OWNED BY public.policy.id;


--
-- Name: policy_resource; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.policy_resource (
    policy_id integer NOT NULL,
    resource_id integer NOT NULL
);


ALTER TABLE public.policy_resource OWNER TO arborist_user;

--
-- Name: policy_role; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.policy_role (
    policy_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.policy_role OWNER TO arborist_user;

--
-- Name: resource; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.resource (
    id integer NOT NULL,
    tag text NOT NULL,
    name text NOT NULL,
    description text,
    path public.ltree NOT NULL
);


ALTER TABLE public.resource OWNER TO arborist_user;

--
-- Name: resource_id_seq; Type: SEQUENCE; Schema: public; Owner: arborist_user
--

CREATE SEQUENCE public.resource_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resource_id_seq OWNER TO arborist_user;

--
-- Name: resource_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arborist_user
--

ALTER SEQUENCE public.resource_id_seq OWNED BY public.resource.id;


--
-- Name: role; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.role (
    id integer NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.role OWNER TO arborist_user;

--
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: arborist_user
--

CREATE SEQUENCE public.role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO arborist_user;

--
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arborist_user
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- Name: usr; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.usr (
    id integer NOT NULL,
    name text NOT NULL,
    email text
);


ALTER TABLE public.usr OWNER TO arborist_user;

--
-- Name: usr_grp; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.usr_grp (
    usr_id integer NOT NULL,
    grp_id integer NOT NULL,
    expires_at timestamp with time zone,
    authz_provider character varying
);


ALTER TABLE public.usr_grp OWNER TO arborist_user;

--
-- Name: usr_id_seq; Type: SEQUENCE; Schema: public; Owner: arborist_user
--

CREATE SEQUENCE public.usr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usr_id_seq OWNER TO arborist_user;

--
-- Name: usr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arborist_user
--

ALTER SEQUENCE public.usr_id_seq OWNED BY public.usr.id;


--
-- Name: usr_policy; Type: TABLE; Schema: public; Owner: arborist_user
--

CREATE TABLE public.usr_policy (
    usr_id integer NOT NULL,
    policy_id integer NOT NULL,
    expires_at timestamp with time zone,
    authz_provider character varying
);


ALTER TABLE public.usr_policy OWNER TO arborist_user;

--
-- Name: client id; Type: DEFAULT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.client ALTER COLUMN id SET DEFAULT nextval('public.client_id_seq'::regclass);


--
-- Name: grp id; Type: DEFAULT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.grp ALTER COLUMN id SET DEFAULT nextval('public.grp_id_seq'::regclass);


--
-- Name: policy id; Type: DEFAULT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy ALTER COLUMN id SET DEFAULT nextval('public.policy_id_seq'::regclass);


--
-- Name: resource id; Type: DEFAULT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.resource ALTER COLUMN id SET DEFAULT nextval('public.resource_id_seq'::regclass);


--
-- Name: role id; Type: DEFAULT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- Name: usr id; Type: DEFAULT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr ALTER COLUMN id SET DEFAULT nextval('public.usr_id_seq'::regclass);


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: arborist_user
--



--
-- Data for Name: client_policy; Type: TABLE DATA; Schema: public; Owner: arborist_user
--



--
-- Data for Name: db_version; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.db_version VALUES (3, '2019-09-03T155025Z_authz_provider');


--
-- Data for Name: grp; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.grp VALUES (1, 'anonymous');
INSERT INTO public.grp VALUES (2, 'logged-in');
INSERT INTO public.grp VALUES (3, 'data_submitters');
INSERT INTO public.grp VALUES (4, 'indexd_admins');


--
-- Data for Name: grp_policy; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.grp_policy VALUES (3, 3, 'user-sync');
INSERT INTO public.grp_policy VALUES (3, 2, 'user-sync');
INSERT INTO public.grp_policy VALUES (3, 7, 'user-sync');
INSERT INTO public.grp_policy VALUES (4, 4, 'user-sync');
INSERT INTO public.grp_policy VALUES (1, 5, 'user-sync');


--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.permission VALUES (1, 'file_upload', 'fence', 'file_upload', '{}', '');
INSERT INTO public.permission VALUES (2, 'workspace_access', 'jupyterhub', 'access', '{}', '');
INSERT INTO public.permission VALUES (3, 'sheepdog_admin_action', 'sheepdog', '*', '{}', '');
INSERT INTO public.permission VALUES (4, 'indexd_admin', 'indexd', '*', '{}', '');
INSERT INTO public.permission VALUES (5, 'admin', '*', '*', '{}', '');
INSERT INTO public.permission VALUES (6, 'creator', '*', 'create', '{}', '');
INSERT INTO public.permission VALUES (7, 'reader', '*', 'read', '{}', '');
INSERT INTO public.permission VALUES (8, 'updater', '*', 'update', '{}', '');
INSERT INTO public.permission VALUES (9, 'deleter', '*', 'delete', '{}', '');
INSERT INTO public.permission VALUES (10, 'storage_creator', '*', 'write-storage', '{}', '');
INSERT INTO public.permission VALUES (11, 'storage_reader', '*', 'read-storage', '{}', '');


--
-- Data for Name: policy; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.policy VALUES (1, 'workspace', 'be able to use workspace');
INSERT INTO public.policy VALUES (2, 'data_upload', 'upload raw data files to S3');
INSERT INTO public.policy VALUES (3, 'services.sheepdog-admin', 'CRUD access to programs and projects');
INSERT INTO public.policy VALUES (4, 'indexd_admin', 'full access to indexd API');
INSERT INTO public.policy VALUES (5, 'open_data_reader', '');
INSERT INTO public.policy VALUES (6, 'all_programs_reader', '');
INSERT INTO public.policy VALUES (7, 'MyFirstProject_submitter', '');
INSERT INTO public.policy VALUES (8, 'TCGA', '');
INSERT INTO public.policy VALUES (9, 'program1', '');


--
-- Data for Name: policy_resource; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.policy_resource VALUES (1, 1);
INSERT INTO public.policy_resource VALUES (2, 2);
INSERT INTO public.policy_resource VALUES (3, 6);
INSERT INTO public.policy_resource VALUES (3, 7);
INSERT INTO public.policy_resource VALUES (4, 9);
INSERT INTO public.policy_resource VALUES (5, 8);
INSERT INTO public.policy_resource VALUES (6, 9);
INSERT INTO public.policy_resource VALUES (7, 12);
INSERT INTO public.policy_resource VALUES (8, 13);
INSERT INTO public.policy_resource VALUES (8, 15);
INSERT INTO public.policy_resource VALUES (8, 16);
INSERT INTO public.policy_resource VALUES (8, 17);
INSERT INTO public.policy_resource VALUES (8, 18);
INSERT INTO public.policy_resource VALUES (8, 19);
INSERT INTO public.policy_resource VALUES (8, 20);
INSERT INTO public.policy_resource VALUES (8, 21);
INSERT INTO public.policy_resource VALUES (8, 22);
INSERT INTO public.policy_resource VALUES (8, 23);
INSERT INTO public.policy_resource VALUES (8, 24);
INSERT INTO public.policy_resource VALUES (8, 25);
INSERT INTO public.policy_resource VALUES (8, 26);
INSERT INTO public.policy_resource VALUES (8, 27);
INSERT INTO public.policy_resource VALUES (8, 28);
INSERT INTO public.policy_resource VALUES (8, 29);
INSERT INTO public.policy_resource VALUES (8, 30);
INSERT INTO public.policy_resource VALUES (8, 31);
INSERT INTO public.policy_resource VALUES (8, 32);
INSERT INTO public.policy_resource VALUES (8, 33);
INSERT INTO public.policy_resource VALUES (8, 34);
INSERT INTO public.policy_resource VALUES (8, 35);
INSERT INTO public.policy_resource VALUES (8, 36);
INSERT INTO public.policy_resource VALUES (8, 37);
INSERT INTO public.policy_resource VALUES (8, 38);
INSERT INTO public.policy_resource VALUES (8, 39);
INSERT INTO public.policy_resource VALUES (8, 40);
INSERT INTO public.policy_resource VALUES (8, 41);
INSERT INTO public.policy_resource VALUES (8, 42);
INSERT INTO public.policy_resource VALUES (8, 43);
INSERT INTO public.policy_resource VALUES (8, 44);
INSERT INTO public.policy_resource VALUES (8, 45);
INSERT INTO public.policy_resource VALUES (8, 46);
INSERT INTO public.policy_resource VALUES (8, 47);
INSERT INTO public.policy_resource VALUES (9, 48);
INSERT INTO public.policy_resource VALUES (9, 50);


--
-- Data for Name: policy_role; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.policy_role VALUES (1, 2);
INSERT INTO public.policy_role VALUES (2, 1);
INSERT INTO public.policy_role VALUES (3, 3);
INSERT INTO public.policy_role VALUES (4, 4);
INSERT INTO public.policy_role VALUES (5, 7);
INSERT INTO public.policy_role VALUES (5, 11);
INSERT INTO public.policy_role VALUES (6, 7);
INSERT INTO public.policy_role VALUES (6, 11);
INSERT INTO public.policy_role VALUES (7, 6);
INSERT INTO public.policy_role VALUES (7, 7);
INSERT INTO public.policy_role VALUES (7, 8);
INSERT INTO public.policy_role VALUES (7, 9);
INSERT INTO public.policy_role VALUES (7, 10);
INSERT INTO public.policy_role VALUES (7, 11);
INSERT INTO public.policy_role VALUES (8, 6);
INSERT INTO public.policy_role VALUES (8, 7);
INSERT INTO public.policy_role VALUES (8, 8);
INSERT INTO public.policy_role VALUES (8, 9);
INSERT INTO public.policy_role VALUES (8, 10);
INSERT INTO public.policy_role VALUES (8, 11);
INSERT INTO public.policy_role VALUES (9, 6);
INSERT INTO public.policy_role VALUES (9, 7);
INSERT INTO public.policy_role VALUES (9, 8);
INSERT INTO public.policy_role VALUES (9, 9);
INSERT INTO public.policy_role VALUES (9, 10);
INSERT INTO public.policy_role VALUES (9, 11);


--
-- Data for Name: resource; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.resource VALUES (1, 'clKRx6VL', 'workspace', NULL, 'workspace');
INSERT INTO public.resource VALUES (2, 'CwwylvBM', 'data_S0file', NULL, 'data_S0file');
INSERT INTO public.resource VALUES (3, 'qGQpqVdE', 'services', NULL, 'services');
INSERT INTO public.resource VALUES (4, '8nACRPHz', 'sheepdog', NULL, 'services.sheepdog');
INSERT INTO public.resource VALUES (5, 'XocN5uIm', 'submission', NULL, 'services.sheepdog.submission');
INSERT INTO public.resource VALUES (6, 'MM_3emmc', 'program', NULL, 'services.sheepdog.submission.program');
INSERT INTO public.resource VALUES (7, 'VuSJVvx0', 'project', NULL, 'services.sheepdog.submission.project');
INSERT INTO public.resource VALUES (8, '3WJUdAqd', 'open', NULL, 'open');
INSERT INTO public.resource VALUES (9, 'X_tYlbtC', 'programs', NULL, 'programs');
INSERT INTO public.resource VALUES (10, '_krCGXdX', 'MyFirstProgram', NULL, 'programs.MyFirstProgram');
INSERT INTO public.resource VALUES (11, 'Rh7S5ybZ', 'projects', NULL, 'programs.MyFirstProgram.projects');
INSERT INTO public.resource VALUES (12, '62mST7F7', 'MyFirstProject', NULL, 'programs.MyFirstProgram.projects.MyFirstProject');
INSERT INTO public.resource VALUES (13, 'J7PthqTF', 'TCGA', NULL, 'programs.TCGA');
INSERT INTO public.resource VALUES (14, 'GCTKhm39', 'projects', NULL, 'programs.TCGA.projects');
INSERT INTO public.resource VALUES (15, 'ie8qNhqd', 'TCGA_S1DLBC', NULL, 'programs.TCGA.projects.TCGA_S1DLBC');
INSERT INTO public.resource VALUES (16, 'y0v9Bpvw', 'TCGA_S1MESO', NULL, 'programs.TCGA.projects.TCGA_S1MESO');
INSERT INTO public.resource VALUES (17, 'fMr4rV_6', 'TCGA_S1PAAD', NULL, 'programs.TCGA.projects.TCGA_S1PAAD');
INSERT INTO public.resource VALUES (18, 'N_jYYH0M', 'TCGA_S1COAD', NULL, 'programs.TCGA.projects.TCGA_S1COAD');
INSERT INTO public.resource VALUES (19, 'jDiHoWNB', 'TCGA_S1LUAD', NULL, 'programs.TCGA.projects.TCGA_S1LUAD');
INSERT INTO public.resource VALUES (20, 'mg6Qyf1x', 'TCGA_S1TGCT', NULL, 'programs.TCGA.projects.TCGA_S1TGCT');
INSERT INTO public.resource VALUES (21, 'Q6PJ1qsE', 'TCGA_S1ESCA', NULL, 'programs.TCGA.projects.TCGA_S1ESCA');
INSERT INTO public.resource VALUES (22, 'BYfgfUTL', 'TCGA_S1CHOL', NULL, 'programs.TCGA.projects.TCGA_S1CHOL');
INSERT INTO public.resource VALUES (23, 'bUDKNEDU', 'TCGA_S1KIRP', NULL, 'programs.TCGA.projects.TCGA_S1KIRP');
INSERT INTO public.resource VALUES (24, '2bdJbCGo', 'TCGA_S1KIRC', NULL, 'programs.TCGA.projects.TCGA_S1KIRC');
INSERT INTO public.resource VALUES (25, 'fCghsW-B', 'TCGA_S1PRAD', NULL, 'programs.TCGA.projects.TCGA_S1PRAD');
INSERT INTO public.resource VALUES (26, '5IbtbJSb', 'TCGA_S1PCPG', NULL, 'programs.TCGA.projects.TCGA_S1PCPG');
INSERT INTO public.resource VALUES (27, 'TgVZE3HA', 'TCGA_S1SARC', NULL, 'programs.TCGA.projects.TCGA_S1SARC');
INSERT INTO public.resource VALUES (28, 'KFqyta8H', 'TCGA_S1LIHC', NULL, 'programs.TCGA.projects.TCGA_S1LIHC');
INSERT INTO public.resource VALUES (29, 'yx0yqwZ8', 'TCGA_S1GBM', NULL, 'programs.TCGA.projects.TCGA_S1GBM');
INSERT INTO public.resource VALUES (30, 'TRv_0QYT', 'TCGA_S1BLCA', NULL, 'programs.TCGA.projects.TCGA_S1BLCA');
INSERT INTO public.resource VALUES (31, '6prlJx1a', 'TCGA_S1UCS', NULL, 'programs.TCGA.projects.TCGA_S1UCS');
INSERT INTO public.resource VALUES (32, 'VHn6pmoM', 'TCGA_S1UCEC', NULL, 'programs.TCGA.projects.TCGA_S1UCEC');
INSERT INTO public.resource VALUES (33, 'AcC870e7', 'TCGA_S1ACC', NULL, 'programs.TCGA.projects.TCGA_S1ACC');
INSERT INTO public.resource VALUES (34, 'tpMZAQh8', 'TCGA_S1KICH', NULL, 'programs.TCGA.projects.TCGA_S1KICH');
INSERT INTO public.resource VALUES (35, '066TOm2Q', 'TCGA_S1READ', NULL, 'programs.TCGA.projects.TCGA_S1READ');
INSERT INTO public.resource VALUES (36, 'ghoPjwIk', 'TCGA_S1OV', NULL, 'programs.TCGA.projects.TCGA_S1OV');
INSERT INTO public.resource VALUES (37, 'uiCDmi46', 'TCGA_S1SKCM', NULL, 'programs.TCGA.projects.TCGA_S1SKCM');
INSERT INTO public.resource VALUES (38, 'CXG4N8zl', 'TCGA_S1UVM', NULL, 'programs.TCGA.projects.TCGA_S1UVM');
INSERT INTO public.resource VALUES (39, '89cb6T4P', 'TCGA_S1THCA', NULL, 'programs.TCGA.projects.TCGA_S1THCA');
INSERT INTO public.resource VALUES (40, 'fth5eSgj', 'TCGA_S1LGG', NULL, 'programs.TCGA.projects.TCGA_S1LGG');
INSERT INTO public.resource VALUES (41, 'R1qPHVL-', 'TCGA_S1LUSC', NULL, 'programs.TCGA.projects.TCGA_S1LUSC');
INSERT INTO public.resource VALUES (42, 'rWGmWnBb', 'TCGA_S1HNSC', NULL, 'programs.TCGA.projects.TCGA_S1HNSC');
INSERT INTO public.resource VALUES (43, 'R4C77GOc', 'TCGA_S1THYM', NULL, 'programs.TCGA.projects.TCGA_S1THYM');
INSERT INTO public.resource VALUES (44, 'FaP8UL36', 'TCGA_S1CESC', NULL, 'programs.TCGA.projects.TCGA_S1CESC');
INSERT INTO public.resource VALUES (45, 'y0smVKl5', 'TCGA_S1BRCA', NULL, 'programs.TCGA.projects.TCGA_S1BRCA');
INSERT INTO public.resource VALUES (46, '8DZf0wFb', 'TCGA_S1STAD', NULL, 'programs.TCGA.projects.TCGA_S1STAD');
INSERT INTO public.resource VALUES (47, 'J1LnZNft', 'TCGA_S1LAML', NULL, 'programs.TCGA.projects.TCGA_S1LAML');
INSERT INTO public.resource VALUES (48, 'bJSIbzUg', 'program1', NULL, 'programs.program1');
INSERT INTO public.resource VALUES (49, '471Z4aWM', 'projects', NULL, 'programs.program1.projects');
INSERT INTO public.resource VALUES (50, 'Plkn77vL', 'P1', NULL, 'programs.program1.projects.P1');
INSERT INTO public.resource VALUES (52, 'evaE1VNB', 'tcga_S0version1_S20', 'Created by sheepdog', 'programs.tcga_S0version1_S20');
INSERT INTO public.resource VALUES (55, '4KSe6p3I', 'projects', NULL, 'programs.tcga_S0version1_S20.projects');
INSERT INTO public.resource VALUES (56, 'e6tQwqDn', 'TCGA_S1READ', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1READ');
INSERT INTO public.resource VALUES (60, 'rFvz6i4E', 'TCGA_S1UCS', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1UCS');
INSERT INTO public.resource VALUES (64, 'naGu_FUC', 'TCGA_S1COAD', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1COAD');
INSERT INTO public.resource VALUES (68, 'qevusFzz', 'TCGA_S1CESC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1CESC');
INSERT INTO public.resource VALUES (72, 'J8yBYn9R', 'TCGA_S1PAAD', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1PAAD');
INSERT INTO public.resource VALUES (112, '3nm9ThM1', 'TCGA_S1THYM', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1THYM');
INSERT INTO public.resource VALUES (128, 'Yomh0Bgh', 'TCGA_S1LIHC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1LIHC');
INSERT INTO public.resource VALUES (132, 'x43xMvhS', 'TCGA_S1KIRC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1KIRC');
INSERT INTO public.resource VALUES (136, 'B8r0JTOh', 'TCGA_S1KICH', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1KICH');
INSERT INTO public.resource VALUES (140, '7Ny2WG5a', 'TCGA_S1DLBC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1DLBC');
INSERT INTO public.resource VALUES (148, 'y57CRYfj', 'TCGA_S1OV', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1OV');
INSERT INTO public.resource VALUES (152, '-yXyPQv_', 'TCGA_S1MESO', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1MESO');
INSERT INTO public.resource VALUES (156, 'uZ-_izK6', 'TCGA_S1LUSC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1LUSC');
INSERT INTO public.resource VALUES (76, '5n1PK6CT', 'TCGA_S1ESCA', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1ESCA');
INSERT INTO public.resource VALUES (80, 'w1V6Twf9', 'TCGA_S1KIRP', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1KIRP');
INSERT INTO public.resource VALUES (84, 'UWCOwgJr', 'TCGA_S1PCPG', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1PCPG');
INSERT INTO public.resource VALUES (88, 'uecuU--w', 'TCGA_S1HNSC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1HNSC');
INSERT INTO public.resource VALUES (92, 'v2sSCzDy', 'TCGA_S1BLCA', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1BLCA');
INSERT INTO public.resource VALUES (96, 'BHk-w5X2', 'TCGA_S1STAD', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1STAD');
INSERT INTO public.resource VALUES (100, '5p366Rds', 'TCGA_S1SARC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1SARC');
INSERT INTO public.resource VALUES (104, '2AkJC1WR', 'TCGA_S1CHOL', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1CHOL');
INSERT INTO public.resource VALUES (108, 'Qn8jT49V', 'TCGA_S1LAML', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1LAML');
INSERT INTO public.resource VALUES (116, 'z2Hnv-QG', 'TCGA_S1ACC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1ACC');
INSERT INTO public.resource VALUES (120, 'KQIUPf3w', 'TCGA_S1SKCM', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1SKCM');
INSERT INTO public.resource VALUES (124, 'JlXId8f4', 'TCGA_S1LUAD', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1LUAD');
INSERT INTO public.resource VALUES (144, '8PyeAuJn', 'TCGA_S1PRAD', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1PRAD');
INSERT INTO public.resource VALUES (160, 'S4wWYS5Z', 'TCGA_S1GBM', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1GBM');
INSERT INTO public.resource VALUES (164, '36h9I_E_', 'TCGA_S1UVM', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1UVM');
INSERT INTO public.resource VALUES (168, '6HOkO0Nq', 'TCGA_S1LGG', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1LGG');
INSERT INTO public.resource VALUES (172, 'Jm8vmUCk', 'TCGA_S1BRCA', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1BRCA');
INSERT INTO public.resource VALUES (176, 'T3f1uG-K', 'TCGA_S1TGCT', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1TGCT');
INSERT INTO public.resource VALUES (180, 'CoV6VHao', 'TCGA_S1UCEC', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1UCEC');
INSERT INTO public.resource VALUES (184, 'jpF3TmNC', 'TCGA_S1THCA', 'Created by sheepdog', 'programs.tcga_S0version1_S20.projects.TCGA_S1THCA');


--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.role VALUES (1, 'file_uploader', '');
INSERT INTO public.role VALUES (2, 'workspace_user', '');
INSERT INTO public.role VALUES (3, 'sheepdog_admin', 'CRUD access to programs and projects');
INSERT INTO public.role VALUES (4, 'indexd_admin', 'full access to indexd API');
INSERT INTO public.role VALUES (5, 'admin', '');
INSERT INTO public.role VALUES (6, 'creator', '');
INSERT INTO public.role VALUES (7, 'reader', '');
INSERT INTO public.role VALUES (8, 'updater', '');
INSERT INTO public.role VALUES (9, 'deleter', '');
INSERT INTO public.role VALUES (10, 'storage_writer', '');
INSERT INTO public.role VALUES (11, 'storage_reader', '');


--
-- Data for Name: usr; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.usr VALUES (1, 'summerhill001@gmail.com', '');
INSERT INTO public.usr VALUES (2, 'username2', '');


--
-- Data for Name: usr_grp; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.usr_grp VALUES (1, 3, NULL, 'user-sync');
INSERT INTO public.usr_grp VALUES (1, 4, NULL, 'user-sync');


--
-- Data for Name: usr_policy; Type: TABLE DATA; Schema: public; Owner: arborist_user
--

INSERT INTO public.usr_policy VALUES (1, 1, NULL, 'user-sync');
INSERT INTO public.usr_policy VALUES (1, 2, NULL, 'user-sync');
INSERT INTO public.usr_policy VALUES (1, 7, NULL, 'user-sync');
INSERT INTO public.usr_policy VALUES (1, 8, NULL, 'user-sync');
INSERT INTO public.usr_policy VALUES (1, 9, NULL, 'user-sync');


--
-- Name: client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arborist_user
--

SELECT pg_catalog.setval('public.client_id_seq', 1, false);


--
-- Name: grp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arborist_user
--

SELECT pg_catalog.setval('public.grp_id_seq', 4, true);


--
-- Name: policy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arborist_user
--

SELECT pg_catalog.setval('public.policy_id_seq', 9, true);


--
-- Name: resource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arborist_user
--

SELECT pg_catalog.setval('public.resource_id_seq', 234, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arborist_user
--

SELECT pg_catalog.setval('public.role_id_seq', 22, true);


--
-- Name: usr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arborist_user
--

SELECT pg_catalog.setval('public.usr_id_seq', 8, true);


--
-- Name: client client_external_client_id_key; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_external_client_id_key UNIQUE (external_client_id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: client_policy client_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.client_policy
    ADD CONSTRAINT client_policy_pkey PRIMARY KEY (client_id, policy_id);


--
-- Name: db_version db_version_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.db_version
    ADD CONSTRAINT db_version_pkey PRIMARY KEY (id);


--
-- Name: grp grp_name_key; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.grp
    ADD CONSTRAINT grp_name_key UNIQUE (name);


--
-- Name: grp grp_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.grp
    ADD CONSTRAINT grp_pkey PRIMARY KEY (id);


--
-- Name: grp_policy grp_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.grp_policy
    ADD CONSTRAINT grp_policy_pkey PRIMARY KEY (grp_id, policy_id);


--
-- Name: permission permission_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (role_id, name);


--
-- Name: policy policy_name_key; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_name_key UNIQUE (name);


--
-- Name: policy policy_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_pkey PRIMARY KEY (id);


--
-- Name: policy_resource policy_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy_resource
    ADD CONSTRAINT policy_resource_pkey PRIMARY KEY (policy_id, resource_id);


--
-- Name: policy_role policy_role_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy_role
    ADD CONSTRAINT policy_role_pkey PRIMARY KEY (policy_id, role_id);


--
-- Name: resource resource_path_key; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.resource
    ADD CONSTRAINT resource_path_key UNIQUE (path);


--
-- Name: resource resource_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.resource
    ADD CONSTRAINT resource_pkey PRIMARY KEY (id);


--
-- Name: resource resource_tag_key; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.resource
    ADD CONSTRAINT resource_tag_key UNIQUE (tag);


--
-- Name: role role_name_key; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_name_key UNIQUE (name);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: usr_grp usr_grp_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr_grp
    ADD CONSTRAINT usr_grp_pkey PRIMARY KEY (usr_id, grp_id);


--
-- Name: usr usr_name_key; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr
    ADD CONSTRAINT usr_name_key UNIQUE (name);


--
-- Name: usr usr_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr
    ADD CONSTRAINT usr_pkey PRIMARY KEY (id);


--
-- Name: usr_policy usr_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr_policy
    ADD CONSTRAINT usr_policy_pkey PRIMARY KEY (usr_id, policy_id);


--
-- Name: permission_idx; Type: INDEX; Schema: public; Owner: arborist_user
--

CREATE INDEX permission_idx ON public.permission USING btree (role_id, service, method);


--
-- Name: resource_path_idx; Type: INDEX; Schema: public; Owner: arborist_user
--

CREATE INDEX resource_path_idx ON public.resource USING gist (path);


--
-- Name: resource resource_has_parent_check; Type: TRIGGER; Schema: public; Owner: arborist_user
--

CREATE CONSTRAINT TRIGGER resource_has_parent_check AFTER INSERT ON public.resource DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.resource_has_parent();


--
-- Name: resource resource_path_compute_name_insert; Type: TRIGGER; Schema: public; Owner: arborist_user
--

CREATE TRIGGER resource_path_compute_name_insert BEFORE INSERT ON public.resource FOR EACH ROW EXECUTE FUNCTION public.resource_path_insert();


--
-- Name: resource resource_path_compute_name_update; Type: TRIGGER; Schema: public; Owner: arborist_user
--

CREATE TRIGGER resource_path_compute_name_update AFTER UPDATE ON public.resource FOR EACH ROW EXECUTE FUNCTION public.resource_path_update();


--
-- Name: grp resource_path_delete_children; Type: TRIGGER; Schema: public; Owner: arborist_user
--

CREATE TRIGGER resource_path_delete_children BEFORE DELETE ON public.grp FOR EACH ROW EXECUTE FUNCTION public.grp_protect_built_in();


--
-- Name: resource resource_path_delete_children; Type: TRIGGER; Schema: public; Owner: arborist_user
--

CREATE TRIGGER resource_path_delete_children AFTER DELETE ON public.resource FOR EACH ROW EXECUTE FUNCTION public.resource_recursive_delete();


--
-- Name: resource resource_path_update_children; Type: TRIGGER; Schema: public; Owner: arborist_user
--

CREATE TRIGGER resource_path_update_children AFTER UPDATE ON public.resource FOR EACH ROW EXECUTE FUNCTION public.resource_recursive_update();


--
-- Name: client_policy client_policy_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.client_policy
    ADD CONSTRAINT client_policy_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id) ON DELETE CASCADE;


--
-- Name: client_policy client_policy_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.client_policy
    ADD CONSTRAINT client_policy_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy(id) ON DELETE CASCADE;


--
-- Name: grp_policy grp_policy_grp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.grp_policy
    ADD CONSTRAINT grp_policy_grp_id_fkey FOREIGN KEY (grp_id) REFERENCES public.grp(id) ON DELETE CASCADE;


--
-- Name: grp_policy grp_policy_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.grp_policy
    ADD CONSTRAINT grp_policy_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy(id) ON DELETE CASCADE;


--
-- Name: permission permission_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.role(id) ON DELETE CASCADE;


--
-- Name: policy_resource policy_resource_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy_resource
    ADD CONSTRAINT policy_resource_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy(id) ON DELETE CASCADE;


--
-- Name: policy_resource policy_resource_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy_resource
    ADD CONSTRAINT policy_resource_resource_id_fkey FOREIGN KEY (resource_id) REFERENCES public.resource(id) ON DELETE CASCADE;


--
-- Name: policy_role policy_role_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy_role
    ADD CONSTRAINT policy_role_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy(id) ON DELETE CASCADE;


--
-- Name: policy_role policy_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.policy_role
    ADD CONSTRAINT policy_role_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.role(id) ON DELETE CASCADE;


--
-- Name: usr_grp usr_grp_grp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr_grp
    ADD CONSTRAINT usr_grp_grp_id_fkey FOREIGN KEY (grp_id) REFERENCES public.grp(id) ON DELETE CASCADE;


--
-- Name: usr_grp usr_grp_usr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr_grp
    ADD CONSTRAINT usr_grp_usr_id_fkey FOREIGN KEY (usr_id) REFERENCES public.usr(id) ON DELETE CASCADE;


--
-- Name: usr_policy usr_policy_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr_policy
    ADD CONSTRAINT usr_policy_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.policy(id) ON DELETE CASCADE;


--
-- Name: usr_policy usr_policy_usr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: arborist_user
--

ALTER TABLE ONLY public.usr_policy
    ADD CONSTRAINT usr_policy_usr_id_fkey FOREIGN KEY (usr_id) REFERENCES public.usr(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

