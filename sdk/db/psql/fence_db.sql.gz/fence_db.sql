--
-- PostgreSQL database dump
--

-- Dumped from database version 13.7 (Debian 13.7-1.pgdg110+1)
-- Dumped by pg_dump version 13.7 (Debian 13.7-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Group; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public."Group" (
    id integer NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public."Group" OWNER TO fence_user;

--
-- Name: Group_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public."Group_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Group_id_seq" OWNER TO fence_user;

--
-- Name: Group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public."Group_id_seq" OWNED BY public."Group".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    username character varying(255),
    id_from_idp character varying,
    display_name character varying,
    phone_number character varying,
    email character varying,
    _last_auth timestamp without time zone DEFAULT now(),
    idp_id integer,
    google_proxy_group_id character varying,
    department_id integer,
    active boolean,
    is_admin boolean,
    additional_info jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public."User" OWNER TO fence_user;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO fence_user;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: access_privilege; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.access_privilege (
    id integer NOT NULL,
    user_id integer,
    group_id integer,
    project_id integer,
    privilege character varying[],
    provider_id integer,
    CONSTRAINT check_access_subject CHECK (((user_id IS NULL) OR (group_id IS NULL)))
);


ALTER TABLE public.access_privilege OWNER TO fence_user;

--
-- Name: access_privilege_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.access_privilege_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.access_privilege_id_seq OWNER TO fence_user;

--
-- Name: access_privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.access_privilege_id_seq OWNED BY public.access_privilege.id;


--
-- Name: application; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.application (
    id integer NOT NULL,
    user_id integer,
    resources_granted character varying[],
    message character varying
);


ALTER TABLE public.application OWNER TO fence_user;

--
-- Name: application_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.application_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.application_id_seq OWNER TO fence_user;

--
-- Name: application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.application_id_seq OWNED BY public.application.id;


--
-- Name: assume_role_cache; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.assume_role_cache (
    arn character varying NOT NULL,
    expires_at integer,
    aws_access_key_id character varying,
    aws_secret_access_key character varying,
    aws_session_token character varying
);


ALTER TABLE public.assume_role_cache OWNER TO fence_user;

--
-- Name: authorization_code; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.authorization_code (
    code character varying(120) NOT NULL,
    client_id character varying(48),
    redirect_uri text,
    response_type text,
    auth_time integer NOT NULL,
    id integer NOT NULL,
    user_id integer,
    nonce character varying,
    refresh_token_expires_in integer,
    _scope text
);


ALTER TABLE public.authorization_code OWNER TO fence_user;

--
-- Name: authorization_code_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.authorization_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authorization_code_id_seq OWNER TO fence_user;

--
-- Name: authorization_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.authorization_code_id_seq OWNED BY public.authorization_code.id;


--
-- Name: authorization_provider; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.authorization_provider (
    id integer NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.authorization_provider OWNER TO fence_user;

--
-- Name: authorization_provider_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.authorization_provider_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.authorization_provider_id_seq OWNER TO fence_user;

--
-- Name: authorization_provider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.authorization_provider_id_seq OWNED BY public.authorization_provider.id;


--
-- Name: blacklisted_token; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.blacklisted_token (
    jti character varying(36) NOT NULL,
    exp bigint
);


ALTER TABLE public.blacklisted_token OWNER TO fence_user;

--
-- Name: bucket; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.bucket (
    id integer NOT NULL,
    name character varying,
    provider_id integer
);


ALTER TABLE public.bucket OWNER TO fence_user;

--
-- Name: bucket_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.bucket_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bucket_id_seq OWNER TO fence_user;

--
-- Name: bucket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.bucket_id_seq OWNED BY public.bucket.id;


--
-- Name: cert_audit_logs; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.cert_audit_logs (
    id bigint NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    operation character varying NOT NULL,
    user_id integer NOT NULL,
    username character varying(255) NOT NULL,
    old_values jsonb DEFAULT '{}'::jsonb,
    new_values jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.cert_audit_logs OWNER TO fence_user;

--
-- Name: cert_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.cert_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cert_audit_logs_id_seq OWNER TO fence_user;

--
-- Name: cert_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.cert_audit_logs_id_seq OWNED BY public.cert_audit_logs.id;


--
-- Name: certificate; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.certificate (
    id integer NOT NULL,
    application_id integer,
    name character varying(40),
    extension character varying,
    data bytea
);


ALTER TABLE public.certificate OWNER TO fence_user;

--
-- Name: certificate_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.certificate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.certificate_id_seq OWNER TO fence_user;

--
-- Name: certificate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.certificate_id_seq OWNED BY public.certificate.id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.client (
    issued_at integer NOT NULL,
    expires_at integer NOT NULL,
    redirect_uri text,
    token_endpoint_auth_method character varying(48),
    grant_type text NOT NULL,
    response_type text NOT NULL,
    scope text NOT NULL,
    client_name character varying(100),
    client_uri text,
    logo_uri text,
    contact text,
    tos_uri text,
    policy_uri text,
    jwks_uri text,
    jwks_text text,
    i18n_metadata text,
    software_id character varying(36),
    software_version character varying(48),
    client_id character varying(40) NOT NULL,
    client_secret character varying(60),
    name character varying(40) NOT NULL,
    description character varying(400),
    user_id integer,
    auto_approve boolean,
    is_confidential boolean,
    _redirect_uris text,
    _allowed_scopes text NOT NULL,
    _default_scopes text
);


ALTER TABLE public.client OWNER TO fence_user;

--
-- Name: cloud_provider; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.cloud_provider (
    id integer NOT NULL,
    name character varying,
    endpoint character varying,
    backend character varying,
    description character varying,
    service character varying
);


ALTER TABLE public.cloud_provider OWNER TO fence_user;

--
-- Name: cloud_provider_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.cloud_provider_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cloud_provider_id_seq OWNER TO fence_user;

--
-- Name: cloud_provider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.cloud_provider_id_seq OWNED BY public.cloud_provider.id;


--
-- Name: compute_access; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.compute_access (
    id integer NOT NULL,
    project_id integer,
    user_id integer,
    group_id integer,
    provider_id integer,
    instances integer,
    cores integer,
    ram bigint,
    floating_ips integer,
    additional_info jsonb
);


ALTER TABLE public.compute_access OWNER TO fence_user;

--
-- Name: compute_access_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.compute_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compute_access_id_seq OWNER TO fence_user;

--
-- Name: compute_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.compute_access_id_seq OWNED BY public.compute_access.id;


--
-- Name: department; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.department (
    id integer NOT NULL,
    name character varying,
    description character varying,
    org_id integer
);


ALTER TABLE public.department OWNER TO fence_user;

--
-- Name: department_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.department_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.department_id_seq OWNER TO fence_user;

--
-- Name: department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.department_id_seq OWNED BY public.department.id;


--
-- Name: event_log; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.event_log (
    id integer NOT NULL,
    action character varying,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    target character varying,
    target_type character varying,
    description character varying
);


ALTER TABLE public.event_log OWNER TO fence_user;

--
-- Name: event_log_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.event_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_log_id_seq OWNER TO fence_user;

--
-- Name: event_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.event_log_id_seq OWNED BY public.event_log.id;


--
-- Name: ga4gh_passport_cache; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.ga4gh_passport_cache (
    passport_hash character varying(64) NOT NULL,
    expires_at bigint NOT NULL,
    user_ids character varying(255)[] NOT NULL
);


ALTER TABLE public.ga4gh_passport_cache OWNER TO fence_user;

--
-- Name: ga4gh_visa_v1; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.ga4gh_visa_v1 (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    ga4gh_visa text NOT NULL,
    source character varying NOT NULL,
    type character varying NOT NULL,
    asserted bigint NOT NULL,
    expires bigint NOT NULL
);


ALTER TABLE public.ga4gh_visa_v1 OWNER TO fence_user;

--
-- Name: ga4gh_visa_v1_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.ga4gh_visa_v1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ga4gh_visa_v1_id_seq OWNER TO fence_user;

--
-- Name: ga4gh_visa_v1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.ga4gh_visa_v1_id_seq OWNED BY public.ga4gh_visa_v1.id;


--
-- Name: gcp_assume_role_cache; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.gcp_assume_role_cache (
    gcp_proxy_group_id character varying NOT NULL,
    expires_at integer,
    gcp_private_key character varying,
    gcp_key_db_entry character varying
);


ALTER TABLE public.gcp_assume_role_cache OWNER TO fence_user;

--
-- Name: google_bucket_access_group; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.google_bucket_access_group (
    id integer NOT NULL,
    bucket_id integer NOT NULL,
    email character varying NOT NULL,
    privileges character varying[]
);


ALTER TABLE public.google_bucket_access_group OWNER TO fence_user;

--
-- Name: google_bucket_access_group_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.google_bucket_access_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.google_bucket_access_group_id_seq OWNER TO fence_user;

--
-- Name: google_bucket_access_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.google_bucket_access_group_id_seq OWNED BY public.google_bucket_access_group.id;


--
-- Name: google_proxy_group; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.google_proxy_group (
    id character varying(90) NOT NULL,
    email character varying NOT NULL
);


ALTER TABLE public.google_proxy_group OWNER TO fence_user;

--
-- Name: google_proxy_group_to_google_bucket_access_group; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.google_proxy_group_to_google_bucket_access_group (
    id integer NOT NULL,
    proxy_group_id character varying NOT NULL,
    access_group_id integer NOT NULL,
    expires bigint
);


ALTER TABLE public.google_proxy_group_to_google_bucket_access_group OWNER TO fence_user;

--
-- Name: google_proxy_group_to_google_bucket_access_group_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.google_proxy_group_to_google_bucket_access_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.google_proxy_group_to_google_bucket_access_group_id_seq OWNER TO fence_user;

--
-- Name: google_proxy_group_to_google_bucket_access_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.google_proxy_group_to_google_bucket_access_group_id_seq OWNED BY public.google_proxy_group_to_google_bucket_access_group.id;


--
-- Name: google_service_account; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.google_service_account (
    id integer NOT NULL,
    google_unique_id character varying NOT NULL,
    client_id character varying(40),
    user_id integer NOT NULL,
    google_project_id character varying NOT NULL,
    email character varying NOT NULL
);


ALTER TABLE public.google_service_account OWNER TO fence_user;

--
-- Name: google_service_account_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.google_service_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.google_service_account_id_seq OWNER TO fence_user;

--
-- Name: google_service_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.google_service_account_id_seq OWNED BY public.google_service_account.id;


--
-- Name: google_service_account_key; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.google_service_account_key (
    id integer NOT NULL,
    key_id character varying NOT NULL,
    service_account_id integer NOT NULL,
    expires bigint,
    private_key character varying
);


ALTER TABLE public.google_service_account_key OWNER TO fence_user;

--
-- Name: google_service_account_key_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.google_service_account_key_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.google_service_account_key_id_seq OWNER TO fence_user;

--
-- Name: google_service_account_key_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.google_service_account_key_id_seq OWNED BY public.google_service_account_key.id;


--
-- Name: hmac_keypair; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.hmac_keypair (
    id integer NOT NULL,
    user_id integer,
    access_key character varying,
    secret_key character varying,
    "timestamp" timestamp without time zone NOT NULL,
    expire integer,
    active boolean
);


ALTER TABLE public.hmac_keypair OWNER TO fence_user;

--
-- Name: hmac_keypair_archive; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.hmac_keypair_archive (
    id integer NOT NULL,
    user_id integer,
    access_key character varying,
    secret_key character varying,
    "timestamp" timestamp without time zone NOT NULL,
    expire integer
);


ALTER TABLE public.hmac_keypair_archive OWNER TO fence_user;

--
-- Name: hmac_keypair_archive_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.hmac_keypair_archive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hmac_keypair_archive_id_seq OWNER TO fence_user;

--
-- Name: hmac_keypair_archive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.hmac_keypair_archive_id_seq OWNED BY public.hmac_keypair_archive.id;


--
-- Name: hmac_keypair_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.hmac_keypair_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hmac_keypair_id_seq OWNER TO fence_user;

--
-- Name: hmac_keypair_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.hmac_keypair_id_seq OWNED BY public.hmac_keypair.id;


--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.identity_provider (
    id integer NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.identity_provider OWNER TO fence_user;

--
-- Name: identity_provider_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.identity_provider_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.identity_provider_id_seq OWNER TO fence_user;

--
-- Name: identity_provider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.identity_provider_id_seq OWNED BY public.identity_provider.id;


--
-- Name: iss_sub_pair_to_user; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.iss_sub_pair_to_user (
    iss character varying NOT NULL,
    sub character varying NOT NULL,
    "fk_to_User" integer NOT NULL,
    extra_info jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.iss_sub_pair_to_user OWNER TO fence_user;

--
-- Name: organization; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.organization (
    id integer NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.organization OWNER TO fence_user;

--
-- Name: organization_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.organization_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organization_id_seq OWNER TO fence_user;

--
-- Name: organization_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.organization_id_seq OWNED BY public.organization.id;


--
-- Name: project; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.project (
    id integer NOT NULL,
    name character varying,
    auth_id character varying,
    description character varying,
    parent_id integer,
    authz character varying
);


ALTER TABLE public.project OWNER TO fence_user;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.project_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_id_seq OWNER TO fence_user;

--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.project_id_seq OWNED BY public.project.id;


--
-- Name: project_to_bucket; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.project_to_bucket (
    id integer NOT NULL,
    project_id integer,
    bucket_id integer,
    privilege character varying[]
);


ALTER TABLE public.project_to_bucket OWNER TO fence_user;

--
-- Name: project_to_bucket_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.project_to_bucket_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_to_bucket_id_seq OWNER TO fence_user;

--
-- Name: project_to_bucket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.project_to_bucket_id_seq OWNED BY public.project_to_bucket.id;


--
-- Name: s3credential; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.s3credential (
    id integer NOT NULL,
    user_id integer,
    access_key character varying,
    "timestamp" timestamp without time zone NOT NULL,
    expire integer
);


ALTER TABLE public.s3credential OWNER TO fence_user;

--
-- Name: s3credential_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.s3credential_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.s3credential_id_seq OWNER TO fence_user;

--
-- Name: s3credential_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.s3credential_id_seq OWNED BY public.s3credential.id;


--
-- Name: service_account_access_privilege; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.service_account_access_privilege (
    id integer NOT NULL,
    project_id integer NOT NULL,
    service_account_id integer NOT NULL
);


ALTER TABLE public.service_account_access_privilege OWNER TO fence_user;

--
-- Name: service_account_access_privilege_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.service_account_access_privilege_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_account_access_privilege_id_seq OWNER TO fence_user;

--
-- Name: service_account_access_privilege_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.service_account_access_privilege_id_seq OWNED BY public.service_account_access_privilege.id;


--
-- Name: service_account_to_google_bucket_access_group; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.service_account_to_google_bucket_access_group (
    id integer NOT NULL,
    service_account_id integer NOT NULL,
    expires bigint,
    access_group_id integer NOT NULL
);


ALTER TABLE public.service_account_to_google_bucket_access_group OWNER TO fence_user;

--
-- Name: service_account_to_google_bucket_access_group_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.service_account_to_google_bucket_access_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_account_to_google_bucket_access_group_id_seq OWNER TO fence_user;

--
-- Name: service_account_to_google_bucket_access_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.service_account_to_google_bucket_access_group_id_seq OWNED BY public.service_account_to_google_bucket_access_group.id;


--
-- Name: storage_access; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.storage_access (
    id integer NOT NULL,
    project_id integer,
    user_id integer,
    group_id integer,
    provider_id integer,
    max_objects bigint,
    max_size bigint,
    max_buckets integer,
    additional_info jsonb,
    CONSTRAINT check_storage_subject CHECK (((user_id IS NULL) OR (group_id IS NULL) OR (project_id IS NULL)))
);


ALTER TABLE public.storage_access OWNER TO fence_user;

--
-- Name: storage_access_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.storage_access_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.storage_access_id_seq OWNER TO fence_user;

--
-- Name: storage_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.storage_access_id_seq OWNED BY public.storage_access.id;


--
-- Name: tag; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.tag (
    user_id integer NOT NULL,
    key character varying NOT NULL,
    value character varying
);


ALTER TABLE public.tag OWNER TO fence_user;

--
-- Name: upstream_refresh_token; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.upstream_refresh_token (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    refresh_token text NOT NULL,
    expires bigint NOT NULL
);


ALTER TABLE public.upstream_refresh_token OWNER TO fence_user;

--
-- Name: upstream_refresh_token_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.upstream_refresh_token_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upstream_refresh_token_id_seq OWNER TO fence_user;

--
-- Name: upstream_refresh_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.upstream_refresh_token_id_seq OWNED BY public.upstream_refresh_token.id;


--
-- Name: user_audit_logs; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.user_audit_logs (
    id bigint NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now() NOT NULL,
    operation character varying NOT NULL,
    old_values jsonb DEFAULT '{}'::jsonb,
    new_values jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.user_audit_logs OWNER TO fence_user;

--
-- Name: user_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.user_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_audit_logs_id_seq OWNER TO fence_user;

--
-- Name: user_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.user_audit_logs_id_seq OWNED BY public.user_audit_logs.id;


--
-- Name: user_google_account; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.user_google_account (
    id integer NOT NULL,
    email character varying NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.user_google_account OWNER TO fence_user;

--
-- Name: user_google_account_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.user_google_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_google_account_id_seq OWNER TO fence_user;

--
-- Name: user_google_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.user_google_account_id_seq OWNED BY public.user_google_account.id;


--
-- Name: user_google_account_to_proxy_group; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.user_google_account_to_proxy_group (
    user_google_account_id integer NOT NULL,
    proxy_group_id character varying NOT NULL,
    expires bigint
);


ALTER TABLE public.user_google_account_to_proxy_group OWNER TO fence_user;

--
-- Name: user_refresh_token; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.user_refresh_token (
    jti character varying NOT NULL,
    userid integer,
    expires bigint
);


ALTER TABLE public.user_refresh_token OWNER TO fence_user;

--
-- Name: user_service_account; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.user_service_account (
    id integer NOT NULL,
    google_unique_id character varying NOT NULL,
    email character varying NOT NULL,
    google_project_id character varying NOT NULL
);


ALTER TABLE public.user_service_account OWNER TO fence_user;

--
-- Name: user_service_account_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.user_service_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_service_account_id_seq OWNER TO fence_user;

--
-- Name: user_service_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.user_service_account_id_seq OWNED BY public.user_service_account.id;


--
-- Name: user_to_bucket; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.user_to_bucket (
    id integer NOT NULL,
    user_id integer,
    bucket_id integer,
    privilege character varying[]
);


ALTER TABLE public.user_to_bucket OWNER TO fence_user;

--
-- Name: user_to_bucket_id_seq; Type: SEQUENCE; Schema: public; Owner: fence_user
--

CREATE SEQUENCE public.user_to_bucket_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_to_bucket_id_seq OWNER TO fence_user;

--
-- Name: user_to_bucket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fence_user
--

ALTER SEQUENCE public.user_to_bucket_id_seq OWNED BY public.user_to_bucket.id;


--
-- Name: user_to_group; Type: TABLE; Schema: public; Owner: fence_user
--

CREATE TABLE public.user_to_group (
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    roles character varying[]
);


ALTER TABLE public.user_to_group OWNER TO fence_user;

--
-- Name: Group id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."Group" ALTER COLUMN id SET DEFAULT nextval('public."Group_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: access_privilege id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.access_privilege ALTER COLUMN id SET DEFAULT nextval('public.access_privilege_id_seq'::regclass);


--
-- Name: application id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.application ALTER COLUMN id SET DEFAULT nextval('public.application_id_seq'::regclass);


--
-- Name: authorization_code id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.authorization_code ALTER COLUMN id SET DEFAULT nextval('public.authorization_code_id_seq'::regclass);


--
-- Name: authorization_provider id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.authorization_provider ALTER COLUMN id SET DEFAULT nextval('public.authorization_provider_id_seq'::regclass);


--
-- Name: bucket id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.bucket ALTER COLUMN id SET DEFAULT nextval('public.bucket_id_seq'::regclass);


--
-- Name: cert_audit_logs id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.cert_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.cert_audit_logs_id_seq'::regclass);


--
-- Name: certificate id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.certificate ALTER COLUMN id SET DEFAULT nextval('public.certificate_id_seq'::regclass);


--
-- Name: cloud_provider id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.cloud_provider ALTER COLUMN id SET DEFAULT nextval('public.cloud_provider_id_seq'::regclass);


--
-- Name: compute_access id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.compute_access ALTER COLUMN id SET DEFAULT nextval('public.compute_access_id_seq'::regclass);


--
-- Name: department id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.department ALTER COLUMN id SET DEFAULT nextval('public.department_id_seq'::regclass);


--
-- Name: event_log id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.event_log ALTER COLUMN id SET DEFAULT nextval('public.event_log_id_seq'::regclass);


--
-- Name: ga4gh_visa_v1 id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.ga4gh_visa_v1 ALTER COLUMN id SET DEFAULT nextval('public.ga4gh_visa_v1_id_seq'::regclass);


--
-- Name: google_bucket_access_group id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_bucket_access_group ALTER COLUMN id SET DEFAULT nextval('public.google_bucket_access_group_id_seq'::regclass);


--
-- Name: google_proxy_group_to_google_bucket_access_group id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_proxy_group_to_google_bucket_access_group ALTER COLUMN id SET DEFAULT nextval('public.google_proxy_group_to_google_bucket_access_group_id_seq'::regclass);


--
-- Name: google_service_account id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_service_account ALTER COLUMN id SET DEFAULT nextval('public.google_service_account_id_seq'::regclass);


--
-- Name: google_service_account_key id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_service_account_key ALTER COLUMN id SET DEFAULT nextval('public.google_service_account_key_id_seq'::regclass);


--
-- Name: hmac_keypair id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.hmac_keypair ALTER COLUMN id SET DEFAULT nextval('public.hmac_keypair_id_seq'::regclass);


--
-- Name: hmac_keypair_archive id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.hmac_keypair_archive ALTER COLUMN id SET DEFAULT nextval('public.hmac_keypair_archive_id_seq'::regclass);


--
-- Name: identity_provider id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.identity_provider ALTER COLUMN id SET DEFAULT nextval('public.identity_provider_id_seq'::regclass);


--
-- Name: organization id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.organization ALTER COLUMN id SET DEFAULT nextval('public.organization_id_seq'::regclass);


--
-- Name: project id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project ALTER COLUMN id SET DEFAULT nextval('public.project_id_seq'::regclass);


--
-- Name: project_to_bucket id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project_to_bucket ALTER COLUMN id SET DEFAULT nextval('public.project_to_bucket_id_seq'::regclass);


--
-- Name: s3credential id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.s3credential ALTER COLUMN id SET DEFAULT nextval('public.s3credential_id_seq'::regclass);


--
-- Name: service_account_access_privilege id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_access_privilege ALTER COLUMN id SET DEFAULT nextval('public.service_account_access_privilege_id_seq'::regclass);


--
-- Name: service_account_to_google_bucket_access_group id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_to_google_bucket_access_group ALTER COLUMN id SET DEFAULT nextval('public.service_account_to_google_bucket_access_group_id_seq'::regclass);


--
-- Name: storage_access id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.storage_access ALTER COLUMN id SET DEFAULT nextval('public.storage_access_id_seq'::regclass);


--
-- Name: upstream_refresh_token id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.upstream_refresh_token ALTER COLUMN id SET DEFAULT nextval('public.upstream_refresh_token_id_seq'::regclass);


--
-- Name: user_audit_logs id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.user_audit_logs_id_seq'::regclass);


--
-- Name: user_google_account id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_google_account ALTER COLUMN id SET DEFAULT nextval('public.user_google_account_id_seq'::regclass);


--
-- Name: user_service_account id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_service_account ALTER COLUMN id SET DEFAULT nextval('public.user_service_account_id_seq'::regclass);


--
-- Name: user_to_bucket id; Type: DEFAULT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_to_bucket ALTER COLUMN id SET DEFAULT nextval('public.user_to_bucket_id_seq'::regclass);


--
-- Data for Name: Group; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: fence_user
--

INSERT INTO public."User" VALUES (2, 'username2', NULL, '', '', '', '2022-09-10 08:01:36.765708', NULL, NULL, NULL, NULL, false, '{}');
INSERT INTO public."User" VALUES (1, 'summerhill001@gmail.com', '103054973688649801410', '', '', 'summerhill001@gmail.com', '2022-09-10 08:01:36.765708', 1, NULL, NULL, NULL, false, '{}');


--
-- Data for Name: access_privilege; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: application; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: assume_role_cache; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: authorization_code; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: authorization_provider; Type: TABLE DATA; Schema: public; Owner: fence_user
--

INSERT INTO public.authorization_provider VALUES (1, 'dbGaP', NULL);
INSERT INTO public.authorization_provider VALUES (2, 'fence', NULL);


--
-- Data for Name: blacklisted_token; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: bucket; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: cert_audit_logs; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: certificate; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: cloud_provider; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: compute_access; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: event_log; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: ga4gh_passport_cache; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: ga4gh_visa_v1; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: gcp_assume_role_cache; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: google_bucket_access_group; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: google_proxy_group; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: google_proxy_group_to_google_bucket_access_group; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: google_service_account; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: google_service_account_key; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: hmac_keypair; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: hmac_keypair_archive; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: fence_user
--

INSERT INTO public.identity_provider VALUES (1, 'google', NULL);


--
-- Data for Name: iss_sub_pair_to_user; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: organization; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: project_to_bucket; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: s3credential; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: service_account_access_privilege; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: service_account_to_google_bucket_access_group; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: storage_access; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: fence_user
--

INSERT INTO public.tag VALUES (1, 'name', 'User One');
INSERT INTO public.tag VALUES (2, 'name', 'John Doe');
INSERT INTO public.tag VALUES (2, 'email', 'johndoe@gmail.com');


--
-- Data for Name: upstream_refresh_token; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: user_audit_logs; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: user_google_account; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: user_google_account_to_proxy_group; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: user_refresh_token; Type: TABLE DATA; Schema: public; Owner: fence_user
--

INSERT INTO public.user_refresh_token VALUES ('6693aa57-0efe-4ef9-859c-380cb5c87647', 1, 1665389313);


--
-- Data for Name: user_service_account; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: user_to_bucket; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Data for Name: user_to_group; Type: TABLE DATA; Schema: public; Owner: fence_user
--



--
-- Name: Group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public."Group_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public."User_id_seq"', 2, true);


--
-- Name: access_privilege_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.access_privilege_id_seq', 1, false);


--
-- Name: application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.application_id_seq', 1, false);


--
-- Name: authorization_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.authorization_code_id_seq', 1, false);


--
-- Name: authorization_provider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.authorization_provider_id_seq', 2, true);


--
-- Name: bucket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.bucket_id_seq', 1, false);


--
-- Name: cert_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.cert_audit_logs_id_seq', 1, false);


--
-- Name: certificate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.certificate_id_seq', 1, false);


--
-- Name: cloud_provider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.cloud_provider_id_seq', 1, false);


--
-- Name: compute_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.compute_access_id_seq', 1, false);


--
-- Name: department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.department_id_seq', 1, false);


--
-- Name: event_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.event_log_id_seq', 1, false);


--
-- Name: ga4gh_visa_v1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.ga4gh_visa_v1_id_seq', 1, false);


--
-- Name: google_bucket_access_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.google_bucket_access_group_id_seq', 1, false);


--
-- Name: google_proxy_group_to_google_bucket_access_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.google_proxy_group_to_google_bucket_access_group_id_seq', 1, false);


--
-- Name: google_service_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.google_service_account_id_seq', 1, false);


--
-- Name: google_service_account_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.google_service_account_key_id_seq', 1, false);


--
-- Name: hmac_keypair_archive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.hmac_keypair_archive_id_seq', 1, false);


--
-- Name: hmac_keypair_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.hmac_keypair_id_seq', 1, false);


--
-- Name: identity_provider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.identity_provider_id_seq', 1, true);


--
-- Name: organization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.organization_id_seq', 1, false);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.project_id_seq', 1, false);


--
-- Name: project_to_bucket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.project_to_bucket_id_seq', 1, false);


--
-- Name: s3credential_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.s3credential_id_seq', 1, false);


--
-- Name: service_account_access_privilege_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.service_account_access_privilege_id_seq', 1, false);


--
-- Name: service_account_to_google_bucket_access_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.service_account_to_google_bucket_access_group_id_seq', 1, false);


--
-- Name: storage_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.storage_access_id_seq', 1, false);


--
-- Name: upstream_refresh_token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.upstream_refresh_token_id_seq', 1, false);


--
-- Name: user_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.user_audit_logs_id_seq', 1, false);


--
-- Name: user_google_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.user_google_account_id_seq', 1, false);


--
-- Name: user_service_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.user_service_account_id_seq', 1, false);


--
-- Name: user_to_bucket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fence_user
--

SELECT pg_catalog.setval('public.user_to_bucket_id_seq', 1, false);


--
-- Name: Group Group_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."Group"
    ADD CONSTRAINT "Group_name_key" UNIQUE (name);


--
-- Name: Group Group_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."Group"
    ADD CONSTRAINT "Group_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: User User_username_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_username_key" UNIQUE (username);


--
-- Name: access_privilege access_privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.access_privilege
    ADD CONSTRAINT access_privilege_pkey PRIMARY KEY (id);


--
-- Name: application application_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.application
    ADD CONSTRAINT application_pkey PRIMARY KEY (id);


--
-- Name: assume_role_cache assume_role_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.assume_role_cache
    ADD CONSTRAINT assume_role_cache_pkey PRIMARY KEY (arn);


--
-- Name: authorization_code authorization_code_code_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.authorization_code
    ADD CONSTRAINT authorization_code_code_key UNIQUE (code);


--
-- Name: authorization_code authorization_code_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.authorization_code
    ADD CONSTRAINT authorization_code_pkey PRIMARY KEY (id);


--
-- Name: authorization_provider authorization_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.authorization_provider
    ADD CONSTRAINT authorization_provider_name_key UNIQUE (name);


--
-- Name: authorization_provider authorization_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.authorization_provider
    ADD CONSTRAINT authorization_provider_pkey PRIMARY KEY (id);


--
-- Name: blacklisted_token blacklisted_token_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.blacklisted_token
    ADD CONSTRAINT blacklisted_token_pkey PRIMARY KEY (jti);


--
-- Name: bucket bucket_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_pkey PRIMARY KEY (id);


--
-- Name: cert_audit_logs cert_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.cert_audit_logs
    ADD CONSTRAINT cert_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: certificate certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT certificate_pkey PRIMARY KEY (id);


--
-- Name: client client_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_name_key UNIQUE (name);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (client_id);


--
-- Name: cloud_provider cloud_provider_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.cloud_provider
    ADD CONSTRAINT cloud_provider_endpoint_key UNIQUE (endpoint);


--
-- Name: cloud_provider cloud_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.cloud_provider
    ADD CONSTRAINT cloud_provider_name_key UNIQUE (name);


--
-- Name: cloud_provider cloud_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.cloud_provider
    ADD CONSTRAINT cloud_provider_pkey PRIMARY KEY (id);


--
-- Name: compute_access compute_access_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.compute_access
    ADD CONSTRAINT compute_access_pkey PRIMARY KEY (id);


--
-- Name: department department_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_name_key UNIQUE (name);


--
-- Name: department department_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_pkey PRIMARY KEY (id);


--
-- Name: event_log event_log_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.event_log
    ADD CONSTRAINT event_log_pkey PRIMARY KEY (id);


--
-- Name: ga4gh_passport_cache ga4gh_passport_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.ga4gh_passport_cache
    ADD CONSTRAINT ga4gh_passport_cache_pkey PRIMARY KEY (passport_hash);


--
-- Name: ga4gh_visa_v1 ga4gh_visa_v1_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.ga4gh_visa_v1
    ADD CONSTRAINT ga4gh_visa_v1_pkey PRIMARY KEY (id);


--
-- Name: gcp_assume_role_cache gcp_assume_role_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.gcp_assume_role_cache
    ADD CONSTRAINT gcp_assume_role_cache_pkey PRIMARY KEY (gcp_proxy_group_id);


--
-- Name: google_bucket_access_group google_bucket_access_group_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_bucket_access_group
    ADD CONSTRAINT google_bucket_access_group_pkey PRIMARY KEY (id);


--
-- Name: google_proxy_group google_proxy_group_email_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_proxy_group
    ADD CONSTRAINT google_proxy_group_email_key UNIQUE (email);


--
-- Name: google_proxy_group google_proxy_group_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_proxy_group
    ADD CONSTRAINT google_proxy_group_pkey PRIMARY KEY (id);


--
-- Name: google_proxy_group_to_google_bucket_access_group google_proxy_group_to_google_bucket_access_group_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_proxy_group_to_google_bucket_access_group
    ADD CONSTRAINT google_proxy_group_to_google_bucket_access_group_pkey PRIMARY KEY (id);


--
-- Name: google_service_account google_service_account_email_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_service_account
    ADD CONSTRAINT google_service_account_email_key UNIQUE (email);


--
-- Name: google_service_account_key google_service_account_key_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_service_account_key
    ADD CONSTRAINT google_service_account_key_pkey PRIMARY KEY (id);


--
-- Name: google_service_account google_service_account_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_service_account
    ADD CONSTRAINT google_service_account_pkey PRIMARY KEY (id);


--
-- Name: hmac_keypair_archive hmac_keypair_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.hmac_keypair_archive
    ADD CONSTRAINT hmac_keypair_archive_pkey PRIMARY KEY (id);


--
-- Name: hmac_keypair hmac_keypair_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.hmac_keypair
    ADD CONSTRAINT hmac_keypair_pkey PRIMARY KEY (id);


--
-- Name: identity_provider identity_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT identity_provider_name_key UNIQUE (name);


--
-- Name: identity_provider identity_provider_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT identity_provider_pkey PRIMARY KEY (id);


--
-- Name: iss_sub_pair_to_user iss_sub_pair_to_user_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.iss_sub_pair_to_user
    ADD CONSTRAINT iss_sub_pair_to_user_pkey PRIMARY KEY (iss, sub);


--
-- Name: organization organization_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_name_key UNIQUE (name);


--
-- Name: organization organization_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.organization
    ADD CONSTRAINT organization_pkey PRIMARY KEY (id);


--
-- Name: project project_auth_id_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_auth_id_key UNIQUE (auth_id);


--
-- Name: project project_name_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_name_key UNIQUE (name);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project_to_bucket project_to_bucket_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project_to_bucket
    ADD CONSTRAINT project_to_bucket_pkey PRIMARY KEY (id);


--
-- Name: s3credential s3credential_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.s3credential
    ADD CONSTRAINT s3credential_pkey PRIMARY KEY (id);


--
-- Name: service_account_access_privilege service_account_access_privilege_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_access_privilege
    ADD CONSTRAINT service_account_access_privilege_pkey PRIMARY KEY (id);


--
-- Name: service_account_to_google_bucket_access_group service_account_to_google_bucket_access_group_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_to_google_bucket_access_group
    ADD CONSTRAINT service_account_to_google_bucket_access_group_pkey PRIMARY KEY (id);


--
-- Name: storage_access storage_access_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.storage_access
    ADD CONSTRAINT storage_access_pkey PRIMARY KEY (id);


--
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT tag_pkey PRIMARY KEY (user_id, key);


--
-- Name: access_privilege uniq_ap; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.access_privilege
    ADD CONSTRAINT uniq_ap UNIQUE (user_id, group_id, project_id);


--
-- Name: upstream_refresh_token upstream_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.upstream_refresh_token
    ADD CONSTRAINT upstream_refresh_token_pkey PRIMARY KEY (id);


--
-- Name: user_audit_logs user_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_audit_logs
    ADD CONSTRAINT user_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: user_google_account user_google_account_email_key; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_google_account
    ADD CONSTRAINT user_google_account_email_key UNIQUE (email);


--
-- Name: user_google_account user_google_account_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_google_account
    ADD CONSTRAINT user_google_account_pkey PRIMARY KEY (id);


--
-- Name: user_google_account_to_proxy_group user_google_account_to_proxy_group_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_google_account_to_proxy_group
    ADD CONSTRAINT user_google_account_to_proxy_group_pkey PRIMARY KEY (user_google_account_id, proxy_group_id);


--
-- Name: user_refresh_token user_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_refresh_token
    ADD CONSTRAINT user_refresh_token_pkey PRIMARY KEY (jti);


--
-- Name: user_service_account user_service_account_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_service_account
    ADD CONSTRAINT user_service_account_pkey PRIMARY KEY (id);


--
-- Name: user_to_bucket user_to_bucket_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_to_bucket
    ADD CONSTRAINT user_to_bucket_pkey PRIMARY KEY (id);


--
-- Name: user_to_group user_to_group_pkey; Type: CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_to_group
    ADD CONSTRAINT user_to_group_pkey PRIMARY KEY (user_id, group_id);


--
-- Name: ix_client_client_secret; Type: INDEX; Schema: public; Owner: fence_user
--

CREATE UNIQUE INDEX ix_client_client_secret ON public.client USING btree (client_secret);


--
-- Name: unique_group_project_id; Type: INDEX; Schema: public; Owner: fence_user
--

CREATE UNIQUE INDEX unique_group_project_id ON public.access_privilege USING btree (group_id, project_id) WHERE (user_id IS NULL);


--
-- Name: unique_user_group_id; Type: INDEX; Schema: public; Owner: fence_user
--

CREATE UNIQUE INDEX unique_user_group_id ON public.access_privilege USING btree (user_id, group_id) WHERE (project_id IS NULL);


--
-- Name: unique_user_project_id; Type: INDEX; Schema: public; Owner: fence_user
--

CREATE UNIQUE INDEX unique_user_project_id ON public.access_privilege USING btree (user_id, project_id) WHERE (group_id IS NULL);


--
-- Name: User User_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_department_id_fkey" FOREIGN KEY (department_id) REFERENCES public.department(id);


--
-- Name: User User_google_proxy_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_google_proxy_group_id_fkey" FOREIGN KEY (google_proxy_group_id) REFERENCES public.google_proxy_group(id) ON DELETE SET NULL;


--
-- Name: User User_idp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_idp_id_fkey" FOREIGN KEY (idp_id) REFERENCES public.identity_provider(id);


--
-- Name: access_privilege access_privilege_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.access_privilege
    ADD CONSTRAINT access_privilege_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."Group"(id) ON DELETE CASCADE;


--
-- Name: access_privilege access_privilege_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.access_privilege
    ADD CONSTRAINT access_privilege_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: access_privilege access_privilege_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.access_privilege
    ADD CONSTRAINT access_privilege_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.authorization_provider(id) ON DELETE CASCADE;


--
-- Name: access_privilege access_privilege_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.access_privilege
    ADD CONSTRAINT access_privilege_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: application application_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.application
    ADD CONSTRAINT application_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id);


--
-- Name: authorization_code authorization_code_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.authorization_code
    ADD CONSTRAINT authorization_code_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: bucket bucket_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.bucket
    ADD CONSTRAINT bucket_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.cloud_provider(id) ON DELETE CASCADE;


--
-- Name: certificate certificate_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT certificate_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.application(id) ON DELETE CASCADE;


--
-- Name: client client_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: compute_access compute_access_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.compute_access
    ADD CONSTRAINT compute_access_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."Group"(id) ON DELETE CASCADE;


--
-- Name: compute_access compute_access_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.compute_access
    ADD CONSTRAINT compute_access_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: compute_access compute_access_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.compute_access
    ADD CONSTRAINT compute_access_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.cloud_provider(id) ON DELETE CASCADE;


--
-- Name: compute_access compute_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.compute_access
    ADD CONSTRAINT compute_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: department department_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.department
    ADD CONSTRAINT department_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organization(id);


--
-- Name: ga4gh_visa_v1 ga4gh_visa_v1_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.ga4gh_visa_v1
    ADD CONSTRAINT ga4gh_visa_v1_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: google_bucket_access_group google_bucket_access_group_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_bucket_access_group
    ADD CONSTRAINT google_bucket_access_group_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: google_proxy_group_to_google_bucket_access_group google_proxy_group_to_google_bucket_access__proxy_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_proxy_group_to_google_bucket_access_group
    ADD CONSTRAINT google_proxy_group_to_google_bucket_access__proxy_group_id_fkey FOREIGN KEY (proxy_group_id) REFERENCES public.google_proxy_group(id) ON DELETE CASCADE;


--
-- Name: google_proxy_group_to_google_bucket_access_group google_proxy_group_to_google_bucket_access_access_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_proxy_group_to_google_bucket_access_group
    ADD CONSTRAINT google_proxy_group_to_google_bucket_access_access_group_id_fkey FOREIGN KEY (access_group_id) REFERENCES public.google_bucket_access_group(id) ON DELETE CASCADE;


--
-- Name: google_service_account_key google_service_account_key_service_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_service_account_key
    ADD CONSTRAINT google_service_account_key_service_account_id_fkey FOREIGN KEY (service_account_id) REFERENCES public.google_service_account(id) ON DELETE CASCADE;


--
-- Name: google_service_account google_service_account_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.google_service_account
    ADD CONSTRAINT google_service_account_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: hmac_keypair_archive hmac_keypair_archive_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.hmac_keypair_archive
    ADD CONSTRAINT hmac_keypair_archive_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: hmac_keypair hmac_keypair_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.hmac_keypair
    ADD CONSTRAINT hmac_keypair_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: iss_sub_pair_to_user iss_sub_pair_to_user_fk_to_User_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.iss_sub_pair_to_user
    ADD CONSTRAINT "iss_sub_pair_to_user_fk_to_User_fkey" FOREIGN KEY ("fk_to_User") REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: project project_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.project(id);


--
-- Name: project_to_bucket project_to_bucket_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project_to_bucket
    ADD CONSTRAINT project_to_bucket_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: project_to_bucket project_to_bucket_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.project_to_bucket
    ADD CONSTRAINT project_to_bucket_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: s3credential s3credential_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.s3credential
    ADD CONSTRAINT s3credential_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: service_account_access_privilege service_account_access_privilege_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_access_privilege
    ADD CONSTRAINT service_account_access_privilege_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: service_account_access_privilege service_account_access_privilege_service_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_access_privilege
    ADD CONSTRAINT service_account_access_privilege_service_account_id_fkey FOREIGN KEY (service_account_id) REFERENCES public.user_service_account(id) ON DELETE CASCADE;


--
-- Name: service_account_to_google_bucket_access_group service_account_to_google_bucket_access_gr_access_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_to_google_bucket_access_group
    ADD CONSTRAINT service_account_to_google_bucket_access_gr_access_group_id_fkey FOREIGN KEY (access_group_id) REFERENCES public.google_bucket_access_group(id) ON DELETE CASCADE;


--
-- Name: service_account_to_google_bucket_access_group service_account_to_google_bucket_access_service_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.service_account_to_google_bucket_access_group
    ADD CONSTRAINT service_account_to_google_bucket_access_service_account_id_fkey FOREIGN KEY (service_account_id) REFERENCES public.user_service_account(id) ON DELETE CASCADE;


--
-- Name: storage_access storage_access_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.storage_access
    ADD CONSTRAINT storage_access_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."Group"(id) ON DELETE CASCADE;


--
-- Name: storage_access storage_access_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.storage_access
    ADD CONSTRAINT storage_access_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON DELETE CASCADE;


--
-- Name: storage_access storage_access_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.storage_access
    ADD CONSTRAINT storage_access_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.cloud_provider(id) ON DELETE CASCADE;


--
-- Name: storage_access storage_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.storage_access
    ADD CONSTRAINT storage_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: tag tag_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT tag_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: upstream_refresh_token upstream_refresh_token_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.upstream_refresh_token
    ADD CONSTRAINT upstream_refresh_token_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: user_google_account_to_proxy_group user_google_account_to_proxy_group_proxy_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_google_account_to_proxy_group
    ADD CONSTRAINT user_google_account_to_proxy_group_proxy_group_id_fkey FOREIGN KEY (proxy_group_id) REFERENCES public.google_proxy_group(id) ON DELETE CASCADE;


--
-- Name: user_google_account_to_proxy_group user_google_account_to_proxy_group_user_google_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_google_account_to_proxy_group
    ADD CONSTRAINT user_google_account_to_proxy_group_user_google_account_id_fkey FOREIGN KEY (user_google_account_id) REFERENCES public.user_google_account(id) ON DELETE CASCADE;


--
-- Name: user_google_account user_google_account_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_google_account
    ADD CONSTRAINT user_google_account_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: User user_google_proxy_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT user_google_proxy_group_id_fkey FOREIGN KEY (google_proxy_group_id) REFERENCES public.google_proxy_group(id);


--
-- Name: user_to_bucket user_to_bucket_bucket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_to_bucket
    ADD CONSTRAINT user_to_bucket_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES public.bucket(id) ON DELETE CASCADE;


--
-- Name: user_to_bucket user_to_bucket_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_to_bucket
    ADD CONSTRAINT user_to_bucket_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- Name: user_to_group user_to_group_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_to_group
    ADD CONSTRAINT user_to_group_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."Group"(id) ON DELETE CASCADE;


--
-- Name: user_to_group user_to_group_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fence_user
--

ALTER TABLE ONLY public.user_to_group
    ADD CONSTRAINT user_to_group_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."User"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

